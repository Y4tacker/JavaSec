package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.embedded.jetty.JettyServletWebServerFactory;
import org.springframework.boot.web.server.ErrorPage;
import org.springframework.boot.web.servlet.server.ConfigurableServletWebServerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;

@SpringBootApplication
public class DemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoApplication.class, args);
    }

//    @Bean
//    public ConfigurableServletWebServerFactory webServerFactory()
//    {
//        JettyServletWebServerFactory factory = new JettyServletWebServerFactory();
//        factory.setPort(9000);
//        factory.setContextPath("/Users/y4tacker/Downloads/spring-shiro/myapp");
//        factory.addErrorPages(new ErrorPage(HttpStatus.NOT_FOUND, "/notfound.html"));
//        return factory;
//    }
//
//    @GetMapping("/hello")
//    public ResponseEntity<String> hello() {
//        return new ResponseEntity<>("hello world", HttpStatus.OK);
//    }

}
